export type Questions = {
    [key: string]: string;
  };